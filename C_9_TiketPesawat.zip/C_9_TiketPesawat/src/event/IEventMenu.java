
package event;


public interface IEventMenu {
    public void selected(int index);
}
