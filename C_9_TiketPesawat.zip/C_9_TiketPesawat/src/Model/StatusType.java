
package Model;

public enum StatusType {
    AVAILABLE, DETAIL, PAY;
}
