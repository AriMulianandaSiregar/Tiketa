
package Exception;


public class InputKosongException extends Exception{
    public InputKosongException(String message){
        super(message);
    }
}
