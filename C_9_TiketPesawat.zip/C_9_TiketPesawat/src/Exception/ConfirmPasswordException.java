
package Exception;


public class ConfirmPasswordException extends Exception{
    public ConfirmPasswordException(String message){
        super(message);
    }
}
