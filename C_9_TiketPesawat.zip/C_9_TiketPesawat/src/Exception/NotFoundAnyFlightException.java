
package Exception;


public class NotFoundAnyFlightException extends Exception{
    public NotFoundAnyFlightException(String message){
        super(message);
    }
}
