
package Exception;


public class CreateACCException extends Exception{
    public CreateACCException(String message){
        super(message);
    }
}
