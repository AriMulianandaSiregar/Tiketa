
package Interface;


public interface ICreate {
   public void create(float jumlah); 
}
