
package Interface;

public interface ILogin {
    public void login(float jumlah);
}
